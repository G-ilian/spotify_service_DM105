# AllOfChapterBaseRestrictions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
