# PagingSimplifiedEpisodeObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedEpisodeObject&gt;**](SimplifiedEpisodeObject.md) |  |  [optional]
