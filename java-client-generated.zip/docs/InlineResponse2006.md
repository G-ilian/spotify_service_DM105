# InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chapters** | [**List&lt;ChapterObject&gt;**](ChapterObject.md) |  | 
