# RecommendationsObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seeds** | [**List&lt;RecommendationSeedObject&gt;**](RecommendationSeedObject.md) | An array of recommendation seed objects.  | 
**tracks** | [**List&lt;TrackObject&gt;**](TrackObject.md) | An array of track objects ordered according to the parameters supplied.  | 
