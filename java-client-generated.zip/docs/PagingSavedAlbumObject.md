# PagingSavedAlbumObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SavedAlbumObject&gt;**](SavedAlbumObject.md) |  |  [optional]
