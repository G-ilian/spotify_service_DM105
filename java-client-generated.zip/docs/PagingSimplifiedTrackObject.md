# PagingSimplifiedTrackObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedTrackObject&gt;**](SimplifiedTrackObject.md) |  |  [optional]
