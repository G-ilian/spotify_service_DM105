# SimplifiedChapterObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
