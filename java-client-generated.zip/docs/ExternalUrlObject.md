# ExternalUrlObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spotify** | **String** | The [Spotify URL](/documentation/web-api/concepts/spotify-uris-ids) for the object.  |  [optional]
