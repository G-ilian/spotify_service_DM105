# CursorObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after** | **String** | The cursor to use as key to find the next page of items. |  [optional]
**before** | **String** | The cursor to use as key to find the previous page of items. |  [optional]
