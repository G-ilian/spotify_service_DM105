# SimplifiedAlbumObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artists** | [**List&lt;SimplifiedArtistObject&gt;**](SimplifiedArtistObject.md) | The artists of the album. Each artist object includes a link in &#x60;href&#x60; to more detailed information about the artist.  | 
