# QueueObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentlyPlaying** | **OneOfQueueObjectCurrentlyPlaying** | The currently playing track or episode. Can be &#x60;null&#x60;. |  [optional]
**queue** | **List&lt;OneOfQueueObjectQueueItems&gt;** | The tracks or episodes in the queue. Can be empty. |  [optional]
