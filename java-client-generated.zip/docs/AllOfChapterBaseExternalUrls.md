# AllOfChapterBaseExternalUrls

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
