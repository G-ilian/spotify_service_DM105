# SimplifiedArtistObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalUrls** | **AllOfSimplifiedArtistObjectExternalUrls** | Known external URLs for this artist.  |  [optional]
**href** | **String** | A link to the Web API endpoint providing full details of the artist.  |  [optional]
**id** | **String** | The [Spotify ID](/documentation/web-api/concepts/spotify-uris-ids) for the artist.  |  [optional]
**name** | **String** | The name of the artist.  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) | The object type.  |  [optional]
**uri** | **String** | The [Spotify URI](/documentation/web-api/concepts/spotify-uris-ids) for the artist.  |  [optional]

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
ARTIST | &quot;artist&quot;
