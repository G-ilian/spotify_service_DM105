# PagingSavedEpisodeObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SavedEpisodeObject&gt;**](SavedEpisodeObject.md) |  |  [optional]
