# AllOfSavedAlbumObjectAlbum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
