# InlineResponse20014

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**devices** | [**List&lt;DeviceObject&gt;**](DeviceObject.md) |  | 
