# AllOfSimplifiedPlaylistObjectExternalUrls

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
