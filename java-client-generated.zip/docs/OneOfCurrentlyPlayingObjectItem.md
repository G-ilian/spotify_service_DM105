# OneOfCurrentlyPlayingObjectItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
