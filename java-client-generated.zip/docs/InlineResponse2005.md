# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audiobooks** | [**List&lt;AudiobookObject&gt;**](AudiobookObject.md) |  | 
