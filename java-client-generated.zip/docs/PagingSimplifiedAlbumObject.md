# PagingSimplifiedAlbumObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedAlbumObject&gt;**](SimplifiedAlbumObject.md) |  |  [optional]
