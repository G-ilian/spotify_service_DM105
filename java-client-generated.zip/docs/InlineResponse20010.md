# InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albums** | [**PagingSimplifiedAlbumObject**](PagingSimplifiedAlbumObject.md) |  | 
