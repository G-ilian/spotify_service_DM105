# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**episodes** | [**List&lt;EpisodeObject&gt;**](EpisodeObject.md) |  | 
