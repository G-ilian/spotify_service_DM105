# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artists** | [**List&lt;ArtistObject&gt;**](ArtistObject.md) |  | 
