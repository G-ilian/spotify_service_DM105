# PagingSavedTrackObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SavedTrackObject&gt;**](SavedTrackObject.md) |  |  [optional]
