# PlaylistTracksRefObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | A link to the Web API endpoint where full details of the playlist&#x27;s tracks can be retrieved.  |  [optional]
**total** | **Integer** | Number of tracks in the playlist.  |  [optional]
