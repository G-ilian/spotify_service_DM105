# FollowersObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | This will always be set to null, as the Web API does not support it at the moment.  |  [optional]
**total** | **Integer** | The total number of followers.  |  [optional]
