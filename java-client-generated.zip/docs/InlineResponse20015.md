# InlineResponse20015

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**markets** | **List&lt;String&gt;** |  |  [optional]
