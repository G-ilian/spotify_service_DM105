# AllOfCurrentlyPlayingContextObjectDevice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
