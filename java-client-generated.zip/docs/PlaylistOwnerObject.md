# PlaylistOwnerObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**displayName** | **String** | The name displayed on the user&#x27;s profile. &#x60;null&#x60; if not available.  |  [optional]
