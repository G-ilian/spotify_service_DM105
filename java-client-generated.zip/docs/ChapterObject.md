# ChapterObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audiobook** | **Object** | The audiobook for which the chapter belongs.  | 
