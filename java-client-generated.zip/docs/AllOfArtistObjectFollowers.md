# AllOfArtistObjectFollowers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
