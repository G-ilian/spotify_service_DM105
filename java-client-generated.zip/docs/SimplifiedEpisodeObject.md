# SimplifiedEpisodeObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
