# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albums** | [**List&lt;AlbumObject&gt;**](AlbumObject.md) |  | 
