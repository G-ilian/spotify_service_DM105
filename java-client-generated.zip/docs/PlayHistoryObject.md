# PlayHistoryObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | **AllOfPlayHistoryObjectTrack** | The track the user listened to. |  [optional]
**playedAt** | [**OffsetDateTime**](OffsetDateTime.md) | The date and time the track was played. |  [optional]
**context** | **AllOfPlayHistoryObjectContext** | The context the track was played from. |  [optional]
