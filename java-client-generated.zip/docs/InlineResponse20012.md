# InlineResponse20012

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audioFeatures** | [**List&lt;AudioFeaturesObject&gt;**](AudioFeaturesObject.md) |  | 
