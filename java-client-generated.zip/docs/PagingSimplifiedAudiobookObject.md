# PagingSimplifiedAudiobookObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedAudiobookObject&gt;**](SimplifiedAudiobookObject.md) |  |  [optional]
