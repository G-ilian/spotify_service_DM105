# EpisodeObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**show** | **Object** | The show on which the episode belongs.  | 
