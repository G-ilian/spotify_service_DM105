# InlineResponse20011

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artists** | [**CursorPagingSimplifiedArtistObject**](CursorPagingSimplifiedArtistObject.md) |  | 
