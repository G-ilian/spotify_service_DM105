# AllOfShowBaseExternalUrls

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
