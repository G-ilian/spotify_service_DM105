# ImageObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | The source URL of the image.  | 
**height** | **Integer** | The image height in pixels.  | 
**width** | **Integer** | The image width in pixels.  | 
