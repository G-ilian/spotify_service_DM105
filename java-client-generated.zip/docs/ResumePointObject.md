# ResumePointObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fullyPlayed** | **Boolean** | Whether or not the episode has been fully played by the user.  |  [optional]
**resumePositionMs** | **Integer** | The user&#x27;s most recent position in the episode in milliseconds.  |  [optional]
