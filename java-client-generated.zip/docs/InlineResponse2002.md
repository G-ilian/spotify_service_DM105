# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tracks** | [**List&lt;TrackObject&gt;**](TrackObject.md) |  | 
