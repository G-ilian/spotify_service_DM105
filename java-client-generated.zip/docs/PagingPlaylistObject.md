# PagingPlaylistObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedPlaylistObject&gt;**](SimplifiedPlaylistObject.md) |  |  [optional]
