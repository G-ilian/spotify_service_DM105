# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shows** | [**List&lt;SimplifiedShowObject&gt;**](SimplifiedShowObject.md) |  | 
