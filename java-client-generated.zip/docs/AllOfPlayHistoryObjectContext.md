# AllOfPlayHistoryObjectContext

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
