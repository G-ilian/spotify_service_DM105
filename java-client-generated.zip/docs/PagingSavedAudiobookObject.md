# PagingSavedAudiobookObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SavedAudiobookObject&gt;**](SavedAudiobookObject.md) |  |  [optional]
