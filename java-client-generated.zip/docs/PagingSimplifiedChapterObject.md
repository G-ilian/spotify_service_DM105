# PagingSimplifiedChapterObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedChapterObject&gt;**](SimplifiedChapterObject.md) |  |  [optional]
