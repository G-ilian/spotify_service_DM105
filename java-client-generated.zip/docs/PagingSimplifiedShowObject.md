# PagingSimplifiedShowObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SimplifiedShowObject&gt;**](SimplifiedShowObject.md) |  |  [optional]
