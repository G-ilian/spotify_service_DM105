# PagingArtistDiscographyAlbumObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;ArtistDiscographyAlbumObject&gt;**](ArtistDiscographyAlbumObject.md) |  |  [optional]
