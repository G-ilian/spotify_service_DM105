# AllOfSavedAudiobookObjectAudiobook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
