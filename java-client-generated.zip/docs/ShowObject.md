# ShowObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**episodes** | **Object** | The episodes of the show.  | 
