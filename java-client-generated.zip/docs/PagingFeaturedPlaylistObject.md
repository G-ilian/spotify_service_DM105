# PagingFeaturedPlaylistObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | The localized message of a playlist.  |  [optional]
**playlists** | [**PagingPlaylistObject**](PagingPlaylistObject.md) |  |  [optional]
