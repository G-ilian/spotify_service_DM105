# PagingPlaylistTrackObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;PlaylistTrackObject&gt;**](PlaylistTrackObject.md) |  |  [optional]
