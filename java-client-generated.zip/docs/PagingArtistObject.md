# PagingArtistObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;ArtistObject&gt;**](ArtistObject.md) |  |  [optional]
