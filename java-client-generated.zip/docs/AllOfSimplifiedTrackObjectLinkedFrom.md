# AllOfSimplifiedTrackObjectLinkedFrom

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
