# CursorPagingPlayHistoryObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;PlayHistoryObject&gt;**](PlayHistoryObject.md) |  |  [optional]
