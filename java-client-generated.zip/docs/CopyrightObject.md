# CopyrightObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | The copyright text for this content.  |  [optional]
**type** | **String** | The type of copyright: &#x60;C&#x60; &#x3D; the copyright, &#x60;P&#x60; &#x3D; the sound recording (performance) copyright.  |  [optional]
