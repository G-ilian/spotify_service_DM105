# PlaylistsplaylistIdtracksTracks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **String** | Spotify URI |  [optional]
