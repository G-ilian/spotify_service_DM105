# OneOfQueueObjectQueueItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
