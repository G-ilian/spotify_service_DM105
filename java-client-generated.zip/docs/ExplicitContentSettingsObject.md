# ExplicitContentSettingsObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filterEnabled** | **Boolean** | When &#x60;true&#x60;, indicates that explicit content should not be played.  |  [optional]
**filterLocked** | **Boolean** | When &#x60;true&#x60;, indicates that the explicit content setting is locked and can&#x27;t be changed by the user.  |  [optional]
