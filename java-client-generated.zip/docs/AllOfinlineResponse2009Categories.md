# AllOfinlineResponse2009Categories

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;CategoryObject&gt;**](CategoryObject.md) |  |  [optional]
