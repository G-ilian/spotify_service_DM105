# AudiobookObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chapters** | **Object** | The chapters of the audiobook.  | 
