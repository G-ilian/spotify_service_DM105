# AllOfSimplifiedPlaylistObjectTracks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
