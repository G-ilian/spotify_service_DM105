# PagingSavedShowObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;SavedShowObject&gt;**](SavedShowObject.md) |  |  [optional]
