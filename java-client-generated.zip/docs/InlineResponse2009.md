# InlineResponse2009

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **AllOfinlineResponse2009Categories** |  | 
