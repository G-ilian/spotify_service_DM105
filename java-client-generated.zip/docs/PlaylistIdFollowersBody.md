# PlaylistIdFollowersBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_public** | **Boolean** | Defaults to &#x60;true&#x60;. If &#x60;true&#x60; the playlist will be included in user&#x27;s public playlists, if &#x60;false&#x60; it will remain private.  |  [optional]
