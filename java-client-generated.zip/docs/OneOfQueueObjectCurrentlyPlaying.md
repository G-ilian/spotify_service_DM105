# OneOfQueueObjectCurrentlyPlaying

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
