# MeShowsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ids** | **List&lt;String&gt;** | A JSON array of the [Spotify IDs](https://developer.spotify.com/documentation/web-api/#spotify-uris-and-ids).   A maximum of 50 items can be specified in one request. *Note: if the &#x60;ids&#x60; parameter is present in the query string, any IDs listed here in the body will be ignored.* |  [optional]
