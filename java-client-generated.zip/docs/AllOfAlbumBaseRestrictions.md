# AllOfAlbumBaseRestrictions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
