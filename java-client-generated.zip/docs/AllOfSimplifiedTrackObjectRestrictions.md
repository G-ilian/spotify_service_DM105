# AllOfSimplifiedTrackObjectRestrictions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
