# DisallowsObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interruptingPlayback** | **Boolean** | Interrupting playback. Optional field. |  [optional]
**pausing** | **Boolean** | Pausing. Optional field. |  [optional]
**resuming** | **Boolean** | Resuming. Optional field. |  [optional]
**seeking** | **Boolean** | Seeking playback location. Optional field. |  [optional]
**skippingNext** | **Boolean** | Skipping to the next context. Optional field. |  [optional]
**skippingPrev** | **Boolean** | Skipping to the previous context. Optional field. |  [optional]
**togglingRepeatContext** | **Boolean** | Toggling repeat context flag. Optional field. |  [optional]
**togglingShuffle** | **Boolean** | Toggling shuffle flag. Optional field. |  [optional]
**togglingRepeatTrack** | **Boolean** | Toggling repeat track flag. Optional field. |  [optional]
**transferringPlayback** | **Boolean** | Transfering playback between devices. Optional field. |  [optional]
