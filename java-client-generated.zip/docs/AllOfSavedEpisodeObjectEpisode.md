# AllOfSavedEpisodeObjectEpisode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
