# AllOfCurrentlyPlayingObjectActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
